/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file implements the laser class functions.
It handles moving the lasers and creating new ones.
*/

#include "ECE_LaserBlast.h"

// Constructor - sets up the laser with texture, speed, and who shot it
ECE_LaserBlast::ECE_LaserBlast(const sf::Texture& tex, sf::Vector2f vel, bool fromPlayer)
    : sf::Sprite(tex), velocity(vel), playerOwned(fromPlayer) {}

// Move the laser based on its velocity
void ECE_LaserBlast::update(float dt)
{
    move(velocity * dt);
}

// Check if the laser went off the screen
bool ECE_LaserBlast::isOffScreen(const sf::RenderWindow& win) const
{
    sf::FloatRect a = getGlobalBounds();
    return (a.top + a.height < 0.f) || (a.top > win.getSize().y);
}

// Returns true if player shot this laser
bool ECE_LaserBlast::isFromPlayer() const
{
    return playerOwned;
}

// Creates a new laser shot by the player
void ECE_LaserBlast::createPlayerLaser(std::list<ECE_LaserBlast>& lasers, const sf::Texture& tex, const sf::FloatRect& playerBounds)
{
    ECE_LaserBlast blast(tex, {0.f, 400.f}, true);
    blast.setPosition(sf::Vector2f(
        playerBounds.left + playerBounds.width / 2.f - 2.f,
        playerBounds.top + playerBounds.height
    ));
    lasers.push_back(blast);
}

// Creates a new laser shot by an enemy
void ECE_LaserBlast::createEnemyLaser(std::list<ECE_LaserBlast>& lasers, const sf::Texture& tex, const sf::FloatRect& enemyBounds)
{
    ECE_LaserBlast blast(tex, {0.f, -300.f}, false);
    blast.setPosition(sf::Vector2f(
        enemyBounds.left + enemyBounds.width / 2.f - 2.f,
        enemyBounds.top
    ));
    lasers.push_back(blast);
}

// Updates all lasers and removes ones that went off screen
void ECE_LaserBlast::updateAllLasers(std::list<ECE_LaserBlast>& lasers, float dt, const sf::RenderWindow& window)
{
    for (auto it = lasers.begin(); it != lasers.end();)
    {
        it->update(dt);
        
        if (it->isOffScreen(window))
        {
            it = lasers.erase(it);
        }
        else
        {
            ++it;
        }
    }
}