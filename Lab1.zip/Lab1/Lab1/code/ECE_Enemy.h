/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file has the enemy class for the bad guys in the game.
Enemies can move around, shoot lasers, and check for collisions.
*/

#pragma once
#include <SFML/Graphics.hpp>
#include "ECE_LaserBlast.h"

// Class for enemy characters in the game
// Enemies can move, shoot, and be destroyed
class ECE_Enemy : public sf::Sprite
{
public:
    // Constructor to create an enemy with a texture
    // tex: the image to use for the enemy
    explicit ECE_Enemy(const sf::Texture& tex);

    // Update enemy position and movement
    // dt: delta time for smooth movement
    // direction: which way to move (1 = right, -1 = left)
    // dropDown: set to true if enemies should drop down
    // win: the game window for boundary checking
    void update(float dt, float direction, bool& dropDown, const sf::RenderWindow& win);
    
    // Check if this enemy should fire a laser
    // returns true if enemy should shoot
    bool shouldFire();
    
    // Make the enemy drop down a bit
    void drop();
    
    // Check if enemy reached the top of screen
    // win: the game window
    // returns true if enemy reached top
    bool hasReachedTop(const sf::RenderWindow& win) const;

    // Check if enemy got hit by a laser
    // laser: the laser to check collision with
    // returns true if collision happened
    bool checkLaserCollision(ECE_LaserBlast& laser);

private:
    float speed = 50.f;    // how fast the enemy moves
};