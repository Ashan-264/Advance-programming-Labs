/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file has the laser class that makes the laser bullets for the game.
The lasers can move around and check if they go off screen.
*/

#pragma once
#include <SFML/Graphics.hpp>
#include <list>

// Class for laser bullets in the game
// This makes the lasers that the player and enemies can shoot
class ECE_LaserBlast : public sf::Sprite
{
public:
    // Constructor to make a new laser
    // tex: the texture for the laser
    // vel: how fast and which way the laser moves
    // fromPlayer: true if player shot it, false if enemy shot it
    ECE_LaserBlast(const sf::Texture& tex, sf::Vector2f vel, bool fromPlayer = true);

    // Move the laser based on its speed
    // dt: time since last frame
    void update(float dt);
    
    // Check if laser went off the screen
    // win: the game window
    // returns true if laser is off screen
    bool isOffScreen(const sf::RenderWindow& win) const;
    
    // Check who shot the laser
    // returns true if player shot it
    bool isFromPlayer() const;

    // Update all the lasers and remove ones that went off screen
    // lasers: list of all lasers to update
    // dt: time since last frame
    // window: the game window
    static void updateAllLasers(std::list<ECE_LaserBlast>& lasers, float dt, const sf::RenderWindow& window);
    
    // Make a new laser from the player
    // lasers: list to add the new laser to
    // tex: texture for the laser
    // playerBounds: where the player is so we can position the laser
    static void createPlayerLaser(std::list<ECE_LaserBlast>& lasers, const sf::Texture& tex, const sf::FloatRect& playerBounds);
    
    // Make a new laser from an enemy
    // lasers: list to add the new laser to
    // tex: texture for the laser
    // enemyBounds: where the enemy is so we can position the laser
    static void createEnemyLaser(std::list<ECE_LaserBlast>& lasers, const sf::Texture& tex, const sf::FloatRect& enemyBounds);

private:
    sf::Vector2f velocity;    // how fast the laser moves
    bool playerOwned;         // true if player shot it
};