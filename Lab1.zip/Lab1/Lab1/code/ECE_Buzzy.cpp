/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file implements the ECE_Buzzy class functions.
It handles player movement and collision detection.
*/

#include "ECE_Buzzy.h"
#include <algorithm>

// Constructor - creates Buzzy with the given texture
ECE_Buzzy::ECE_Buzzy(const sf::Texture& texture) : sf::Sprite(texture) {}

// Update Buzzy's position based on keyboard input
void ECE_Buzzy::update(float time, const sf::RenderWindow& win)
{
    const float speed = 300.f; // how fast Buzzy moves
    auto pos = getPosition();

    // Check for left and right arrow keys
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left)) pos.x -= speed * time;
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right)) pos.x += speed * time;

    // Keep Buzzy on screen
    pos.x = std::max(0.f, std::min(
        pos.x, (float)win.getView().getSize().x - (float)getGlobalBounds().getSize().x
    ));
    setPosition(pos);
}

// Check if Buzzy collided with a laser
bool ECE_Buzzy::checkLaserCollision(ECE_LaserBlast& laser)
{
    sf::FloatRect buzzyBounds = getGlobalBounds();
    sf::FloatRect laserBounds = laser.getGlobalBounds();
    return buzzyBounds.left < laserBounds.left + laserBounds.width &&
           buzzyBounds.left + buzzyBounds.width > laserBounds.left &&
           buzzyBounds.top < laserBounds.top + laserBounds.height &&
           buzzyBounds.top + buzzyBounds.height > laserBounds.top;
}