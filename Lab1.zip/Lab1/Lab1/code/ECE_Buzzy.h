/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file has the player class called ECE_Buzzy.
It handles moving the player around and checking for collisions.
*/

#pragma once
#include <SFML/Graphics.hpp>
#include "ECE_LaserBlast.h"

// Class for the player character Buzzy
// Can move left and right and check for laser hits
class ECE_Buzzy : public sf::Sprite
{
public:
    // Constructor to create Buzzy with a texture
    // texture: the image to use for Buzzy
    explicit ECE_Buzzy(const sf::Texture& texture);
    
    // Update Buzzy's position based on keyboard input
    // time: delta time for smooth movement
    // window: the game window for boundary checking
    void update(float time, const sf::RenderWindow& window);
    
    // Check if Buzzy got hit by a laser
    // laser: the laser to check collision with
    // returns true if collision happened
    bool checkLaserCollision(ECE_LaserBlast& laser);
};

