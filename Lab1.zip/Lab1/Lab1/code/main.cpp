
/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This is the main file for the Buzzy Defender game.
It has the game loop and handles all the game logic.
*/

#include "ECE_Buzzy.h"
#include "ECE_Enemy.h"
#include "ECE_LaserBlast.h"
#include "Global.hpp"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <ctime>
#include <list>
#include <vector>

// Global variable to track if game is over
bool gameOver = false;

// Function to make colored rectangles for lasers
// size: how big to make the texture
// color: what color to make it
// returns the texture
static sf::Texture makeSolidTexture(sf::Vector2u size, sf::Color color)
{
    sf::Image img;
    img.create(size.x, size.y, color);
    sf::Texture tex;
    tex.loadFromImage(img);
    return tex;
}

// Main function - this is where the game starts
int main()
{
    // Set up random numbers for enemy shooting
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    // Create the game window
    const unsigned W = 800, H = 600;
    sf::RenderWindow window(sf::VideoMode(W, H), "Buzzy Defender");
    window.setFramerateLimit(60);

    // Load all the texture files
    sf::Texture buzzyTex;
    if (!buzzyTex.loadFromFile("graphics/Buzzy_blue.png"))
    {
        std::cerr << "Could not load Buzzy texture!\n";
        return -1;
    }
    
    sf::Texture bulldogTex;
    if (!bulldogTex.loadFromFile("graphics/bulldog.png"))
    {
        std::cerr << "Could not load bulldog texture!\n";
        return -1;
    }

    sf::Texture tigerTex;
    if (!tigerTex.loadFromFile("graphics/clemson_tigers.png"))
    {
        std::cerr << "Could not load tiger texture!\n";
        return -1;
    }

    // How much to scale down the sprites
    const float SPRITE_SCALE = 0.1f; // Scale for bulldogs
    const float TIGER_SCALE = 0.05f; // Smaller scale for tigers

    // Make colored rectangles for the lasers
    sf::Texture playerLaserTex = makeSolidTexture({4, 12}, sf::Color::Cyan);
    sf::Texture enemyLaserTex = makeSolidTexture({4, 12}, sf::Color::Red);

    // Load the font for text
    sf::Font font;
    if (!font.loadFromFile("graphics/arial.ttf"))
    {
        std::cerr << "Could not load font!\n";
        return -1;
    }

    sf::Text infoText("", font, 24);
    infoText.setFillColor(sf::Color::White);
    infoText.setPosition(10.f, 10.f);
   
    sf::Text centerText("", font, 32);
    centerText.setFillColor(sf::Color::White);
    centerText.setPosition(W / 4.f, H / 2.f - 50.f);

    // Create the player character
    ECE_Buzzy buzzy(buzzyTex);
    buzzy.setScale(sf::Vector2f(SPRITE_SCALE, SPRITE_SCALE));  // Make Buzzy smaller
    buzzy.setPosition(sf::Vector2f(W * 0.5f - buzzy.getGlobalBounds().width * 0.5f,
                                   20.f));  // Put Buzzy at the top

    std::vector<ECE_Enemy> enemies;
    std::list<ECE_LaserBlast> lasers;

    // Game variables
    int score = 0;
    int lives = 3;
    float enemyDirection = 1.f;
    sf::Clock clock;
    sf::Clock laserCooldown;  // Timer for shooting
    const float LASER_COOLDOWN_TIME = 0.5f;  // How long between shots
    GameState state = GameState::Start;

    // Function to restart the game
    auto resetGame = [&]()
    {
        // Reset everything back to starting values
        score = 0;
        lives = 3;
        enemies.clear();
        lasers.clear();
        
        // Create rows of enemies
        for (int row = 0; row < 4; ++row)
        {
            for (int col = 0; col < 8; ++col)
            {
                // Use different enemy types for each row
                const sf::Texture& enemyTexture = (row % 2 == 0) ? tigerTex : bulldogTex;
                enemies.emplace_back(enemyTexture);
                // Make tigers smaller than bulldogs
                float scale = (row % 2 == 0) ? TIGER_SCALE : SPRITE_SCALE;
                enemies.back().setScale(sf::Vector2f(scale, scale));
                enemies.back().setPosition(sf::Vector2f(
                    80.f + col * 80.f,  // X position
                    H - 100.f - (row * 60.f)  // Y position
                ));
            }
        }
        
        // Put Buzzy back at starting position
        buzzy.setPosition(sf::Vector2f(W * 0.5f - buzzy.getGlobalBounds().width * 0.5f,
                          20.f));  // Reset Buzzy to top
        enemyDirection = 1.f;
        state = GameState::Playing;
    };

    // Main game loop - runs until window is closed
    while (window.isOpen())
    {
        // Check for events like key presses
        sf::Event e;
        while (window.pollEvent(e))
        {
            if (e.type == sf::Event::Closed) window.close();

            // Handle Enter key for different screens
            if (state == GameState::Start &&
                e.type == sf::Event::KeyPressed && e.key.code == sf::Keyboard::Enter)
            {
                resetGame();
            }

            // Restart from game over screen
            if (state == GameState::GameOver &&
                e.type == sf::Event::KeyPressed && e.key.code == sf::Keyboard::Enter) {
                resetGame();
            }

            // Victory screen input handling
            if (state == GameState::Victory &&
                e.type == sf::Event::KeyPressed && e.key.code == sf::Keyboard::Enter) {
                resetGame();
            }

            // Player laser firing during gameplay
            if (state == GameState::Playing &&
                e.type == sf::Event::KeyPressed && e.key.code == sf::Keyboard::Space &&
                laserCooldown.getElapsedTime().asSeconds() >= LASER_COOLDOWN_TIME) {
                ECE_LaserBlast::createPlayerLaser(lasers, playerLaserTex, buzzy.getGlobalBounds());
                laserCooldown.restart();  // Reset the cooldown timer
            }
        }

        // Calculate delta time for frame-rate independent movement
        float dt = clock.restart().asSeconds();

        // Game logic per state
        if (state == GameState::Playing) {
            // Update player movement
            buzzy.update(dt, window);

            // Update enemy movement and behavior
            bool dropDown = false;
            bool enemyReachedTop = false;
            for (auto& en : enemies) {
                en.update(dt, enemyDirection, dropDown, window);
                
                // Check if any enemy reached the top (game over condition)
                if (en.hasReachedTop(window)) {
                    enemyReachedTop = true;
                    break;
                }
                
                // Random enemy firing
                if (en.shouldFire()) {
                    ECE_LaserBlast::createEnemyLaser(lasers, enemyLaserTex, en.getGlobalBounds());
                }
            }
            
            // Handle enemy formation reaching screen edge
            if (dropDown) {
                enemyDirection *= -1.f;
                for (auto& en : enemies) en.drop();
            }

            // Update all laser positions and remove off-screen ones
            ECE_LaserBlast::updateAllLasers(lasers, dt, window);

            // Collision detection and handling
            for (auto it = lasers.begin(); it != lasers.end();) {
                bool remove = false;
                if (it->isFromPlayer()) {
                    // Player laser vs enemies collision
                    for (auto enIt = enemies.begin(); enIt != enemies.end();) {
                        if (it->getGlobalBounds().intersects(enIt->getGlobalBounds())) {
                            enIt = enemies.erase(enIt);
                            score += 10;
                            remove = true;
                            break;
                        } else {
                            ++enIt;
                        }
                    }
                } else {
                    // Enemy laser vs player collision
                    if (it->getGlobalBounds().intersects(buzzy.getGlobalBounds())) {
                        lives--;
                        remove = true;
                        if (lives <= 0) {
                            state = GameState::GameOver;
                        }
                    }
                }

                if (remove) it = lasers.erase(it);
                else ++it;
            }

            // Check victory condition
            if (enemies.empty()) {
                state = GameState::Victory;
            }
        }

        // Rendering based on current game state
        window.clear(sf::Color(20, 20, 30));

        if (state == GameState::Start) {
            centerText.setPosition(sf::Vector2f(W / 2.f - centerText.getGlobalBounds().width / 2.f, H / 3.f));            
            centerText.setString("Start Screen\n\nPress ENTER to Start");
            window.draw(centerText);
        }
        else if (state == GameState::Playing) {
            // Draw all game objects
            for (auto& en : enemies) window.draw(en);
            for (auto& l : lasers) window.draw(l);
            window.draw(buzzy);
            
            // Draw UI: score and lives
            infoText.setString("Score: " + std::to_string(score) + "\nLives: " + std::to_string(lives));
            window.draw(infoText);
        }
        else if (state == GameState::GameOver) {
            centerText.setPosition(sf::Vector2f(W / 2.f - centerText.getGlobalBounds().width / 2.f, H / 3.f));
            centerText.setString("Start Screen\n\nGame Over!\nThe enemies have reached your base!\nScore: " + std::to_string(score) + "\n\nPress ENTER to try again");
            window.draw(centerText);
        }
        else if (state == GameState::Victory) {
            centerText.setPosition(sf::Vector2f(W / 2.f - centerText.getGlobalBounds().width / 2.f, H / 3.f));
            centerText.setString("Start Screen\n\nVictory!\nScore: " + std::to_string(score) + "\n\nPress ENTER to Play Again");
            window.draw(centerText);
        }

        window.display();
    }
}
