/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file has global variables and constants for the game.
It defines screen size and game states.
*/

#pragma once

// Screen size constants
constexpr int SCREEN_WIDTH = 800;
constexpr int SCREEN_HEIGHT = 600;
constexpr int BASE_SIZE = 64;

// Player movement speed
constexpr int PLAYER_MOVE_SPEED = 5;
constexpr int SCREEN = SCREEN_WIDTH - BASE_SIZE;

// Different states the game can be in
enum class GameState 
{
    Start,      // Start screen
    Playing,    // Playing the game
    GameOver,   // Game over screen
    Victory     // Victory screen
};