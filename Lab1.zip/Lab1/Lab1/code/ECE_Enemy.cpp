/*
Author: Ashan Deen
Class: ECE4122 or ECE6122
Last Date Modified: 9/18/2025

Description:
This file implements the ECE_Enemy class functions.
It handles enemy movement, shooting, and collision detection.
*/

#include "ECE_Enemy.h"

// Constructor - creates an enemy with the given texture
ECE_Enemy::ECE_Enemy(const sf::Texture& tex) : sf::Sprite(tex) {}

// Update enemy position and check if it hit screen edge
void ECE_Enemy::update(float dt, float direction, bool& dropDown, const sf::RenderWindow& win)
{
    move(sf::Vector2f(direction * speed * dt, 0.f));

    sf::FloatRect bounds = getGlobalBounds();
    if (bounds.left < 0.f ||
        bounds.left + bounds.width > win.getView().getSize().x)
    {
        dropDown = true;
    }
}

// Random chance for enemy to shoot
bool ECE_Enemy::shouldFire()
{
    return (std::rand() % 1000 < 1);
}

// Move enemy down when it hits screen edge
void ECE_Enemy::drop()
{
    move(sf::Vector2f(0.f, -20.f));
}

// Check if enemy reached top of screen (game over)
bool ECE_Enemy::hasReachedTop(const sf::RenderWindow& win) const
{
    return getGlobalBounds().top <= 0.f;
}

// Check if enemy collided with a laser
bool ECE_Enemy::checkLaserCollision(ECE_LaserBlast& laser)
{
    sf::FloatRect enemyBounds = getGlobalBounds();
    sf::FloatRect laserBounds = laser.getGlobalBounds();
    return enemyBounds.left < laserBounds.left + laserBounds.width &&
           enemyBounds.left + enemyBounds.width > laserBounds.left &&
           enemyBounds.top < laserBounds.top + laserBounds.height &&
           enemyBounds.top + enemyBounds.height > laserBounds.top;
}